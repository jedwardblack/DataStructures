
public class Item {

	private double price;
	private String name;
	private int quantity;
	
	//Default constructor
	public Item() {
		new Item(0, "name", 0.0);
		
	}
	
	//Constructor
	public Item(int newQuantity, String newName, double newPrice) {
		quantity = newQuantity;
		name = newName;
		price = newPrice;
	}

	//Returns quantity.
	public int getQuantity() {
		return this.quantity;
	}

	//Returns price.
	public double getPrice() {
		return this.price;
	}
	
	//Sets name.
	public void setName(String name) {
		this.name = name;
	}
	
	//Returns name.
	public String getName() {
		return this.name;
	}
	

}
